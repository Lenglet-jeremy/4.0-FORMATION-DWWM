const router = require("express").Router();
const connection = require("../../database/configDB");

// route qui récupère toutes les todos
router.get("/", (req, res) => {
  const sql = "SELECT * FROM todos";
  connection.query(sql, (err, result) => {
    if (err) throw err;
    console.log("Todos récupérées");
    console.log(result);
    res.status(200).json(result);
  });
});

// route qui ajoute une todo
router.post("/addTodo", (req, res) => {
  console.log(req.body);
  const { content, done, edit } = req.body;
  const insertSql = "INSERT INTO todos (content, done, edit) VALUES (?, ?, ?)";
  connection.query(insertSql, [content, done, edit], (err, result) => {
    console.log("result1", result);
    if (err) throw err;
    let lastInsertId = result.insertId;
    let sqlLastOne = "SELECT * FROM todos WHERE _id = ?";
    connection.query(sqlLastOne, [lastInsertId], (err, result) => {
      console.log("result2", result);
      res.status(200).json(result[0]);
    });
  });
});

// route qui supprime une todo
router.delete("/delete/:id", (req, res) => {
  const _id = req.params.id;
  const deleteSql = "DELETE FROM todos WHERE _id = ?";
  connection.query(deleteSql, [_id], (err, result) => {
    if (err) throw err;
    res.status(200).json({ message: "Todo supprimée" });
  });
});

// route qui modifie une todo
router.patch("/update", (req, res) => {
  console.log(req.body);
  const done = req.body.done === true ? 1 : 0;
  const edit = req.body.done === true ? 1 : 0;
  const _id = req.body._id;
  const content = req.body.content;
  const updateSql = "UPDATE todos SET content =?, done=?, edit= ? WHERE _id=?";
  connection.query(updateSql, [content, done, edit, _id], (err, result) => {
    if (err) throw err;
    console.log("todo.modifiée en BDD");
    res.status(200).json(req.body);
  });
});

module.exports = router;
